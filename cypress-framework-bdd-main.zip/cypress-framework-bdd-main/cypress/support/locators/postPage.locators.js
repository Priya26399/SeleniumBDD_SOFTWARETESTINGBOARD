const POST_PAGE_HEADER = '//span[contains(@class,"blog-post-title")]';

const POST_AUTHOR = '//span[contains(@data-hook,"user-name")]';

module.exports = {
    POST_PAGE_HEADER,
    POST_AUTHOR
}